<!-- <style type="text/css">
    h2{
        background-image: none;
    }
    h3{
        padding: 4px 0 0 10px;
    }
    .btn-primary{
        display: block;
        width: 120px;
        height: 25px;
        background: #4E9CAF;
        padding: 10px;
        text-align: center;
        border-radius: 5px;
        color: white;
        font-weight: bold;
        line-height: 25px;
        text-decoration: none;
        margin: 10px 0 0 10px;
    }
</style> -->
<div class="template-register">
    <h2 style="background-image: none;">Email Confirmation</h3>
    <h3 style="padding: 4px 0 0 10px;">Hey <?= $user; ?>, thanks for joining.</h3>
    <h3 style="padding: 4px 0 0 10px;">Simply click the big button to verify your email address</h3>
    <a href="#" 
        class="btn btn-primary"
        style="
            display: block;
            width: 120px;
            height: 25px;
            background: #4E9CAF;
            padding: 10px;
            text-align: center;
            border-radius: 5px;
            color: white;
            font-weight: bold;
            line-height: 25px;
            text-decoration: none;
            margin: 10px 0 0 10px;
        "
    >
        Verify Email Address
    </a>
</div>
