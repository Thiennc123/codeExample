<?php

namespace app\modules\api\controllers\web;
use yii\rest\Controller;
use app\modules\api\models\User;
use sizeg\jwt\JwtHttpBearerAuth;

class UserController extends Controller
{
    // public $modelClass = 'app\modules\api\models\User';
    public function behaviors()
    {
        $behaviors = parent::behaviors();
        $behaviors['authenticator'] = [
            'class'    => JwtHttpBearerAuth::class,
            'optional' => [
                'create',
            ],
        ];

        return $behaviors;
    }

    public function actionIndex()
    {
        $user = User::find()->all();
        return $this->asJson([
            'user' => $user,
            'code' => '0000',
        ]);
    }

}
