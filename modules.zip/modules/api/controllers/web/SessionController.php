<?php

namespace app\modules\api\controllers\web;

use app\modules\api\models\User;
use sizeg\jwt\Jwt;
use sizeg\jwt\JwtHttpBearerAuth;
use Yii;
use yii\data\ActiveDataProvider;

class SessionController extends \yii\rest\Controller
{
    // public $modelClass = 'app\modules\api\models\User';
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        $behaviors = parent::behaviors();
        // unset($behaviors['authenticator']);
        $behaviors['corsFilter'] = [
            'class' => \yii\filters\Cors::class,
            'cors' => [
                'Origin' => ['*'],
                'Access-Control-Request-Method' => ['GET', 'POST', 'OPTIONS'],
                'Access-Control-Request-Headers' => ['Origin', 'X-Requested-With', 'Content-Type', 'accept', 'Authorization'],
                'Access-Control-Allow-Credentials' => true,
                'Access-Control-Max-Age'           => 3600,
                'Access-Control-Allow-Origin' => true,
                'Access-Control-Allow-Headers' => ['*'],
            ],
        ];
        $behaviors['authenticator'] = [
            'class'    => JwtHttpBearerAuth::class,
            'optional' => [
                'create',
            ],
            // 'authMethods' => [
            //     HttpBasicAuth::className(),
            //     HttpBearerAuth::className(),
            //     QueryParamAuth::className(),
            // ],
        ];

        $behaviors['authenticator']['except'] = ['options'];
        // print_r($behaviors);
        // die;

        return $behaviors;
    }

    // public function actions(){
    //     $actions = parent::actions();

    //     unset(
    //         $actions[ 'index' ],
    //         $actions[ 'view' ],
    //         $actions[ 'create' ],
    //         $actions[ 'update' ],
    //         $actions[ 'delete' ],
    //         $actions[ 'options' ]
    //     );


    //     return $actions;
    // }

    // public function verbs(){
    //     return [
    //         'create' => ['POST', 'OPTIONS']
    //     ];
    // }

    public function actionCreate()
    {
        Yii::$app->mailer->compose('@app/modules/api/views/mail-templates/register', ['token' => 'asqwehb1213kjnewqjnsd', 'user' => 'Brian Phan'])
         ->setFrom('somebody@domain.com')
         ->setTo('123@yopmail.com')
         ->setSubject('Email sent from AirAgri')
         ->send();

        $email    = Yii::$app->request->post('email');
        $password = Yii::$app->request->post('password');

        $provider = new ActiveDataProvider([
            'query' => User::find()
                ->where(['email' => $email])->asArray()->one(),
        ]);

        $result = $provider->query;

        if ($result) {
            if (Yii::$app->getSecurity()->validatePassword($password, $result['password'])) {
                $jwt    = Yii::$app->jwt;
                $signer = $jwt->getSigner('HS256');
                $key    = $jwt->getKey();
                $time   = time();

                $token = $jwt->getBuilder()
                    ->issuedBy('http://example.com') // Configures the issuer (iss claim)
                    ->permittedFor('http://example.org') // Configures the audience (aud claim)
                    ->identifiedBy('4f1g23a12aa', true) // Configures the id (jti claim), replicating as a header item
                    ->issuedAt($time) // Configures the time that the token was issue (iat claim)
                    ->expiresAt($time + 3600) // Configures the expiration time of the token (exp claim)
                    ->withClaim('uid', 100) // Configures a new claim, called "uid"
                    ->getToken($signer, $key); // Retrieves the generated token

                $response = [
                    'code'         => '0000',
                    'access_token' => (string) $token,
                ];
            } else {
                $response = [
                    'code'    => '0000',
                    'message' => 'Invalid email or password.',
                ];
            }
        } else {
            $response = [
                'code'    => '0000',
                'message' => 'Invalid email or password.',
            ];
        }

        return $response;
    }

}
